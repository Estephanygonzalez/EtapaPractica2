import javax.lang.model.SourceVersion;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        System.out.println("Hola Mundo");
        String nombre = "Estephany";
        System.out.println("Hola Mi nombre es :" + nombre);

        String saludar = "Hola Mundo";
        System.out.println(saludar);
        System.out.println("saludar.toUppercase()=" + saludar.toUpperCase());

        //Tipos Primitivos

        int numero = 10;


        boolean valor = true;
        int numero1 = 5;
        if (valor) {
            System.out.println(" valor = " + valor);
            numero1 = 10;
        }
        System.out.println("numero1= " + numero1);

        var numero2 = "15";

        String nombre1;
        nombre1 = "Laura";

        if (numero1 >10){
            nombre1 = "juan";
        }
        System.out.println("nombre1 = " + nombre1);


    }

}