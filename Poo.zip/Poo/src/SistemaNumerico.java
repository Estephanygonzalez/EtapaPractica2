import javax.swing.*;

public class SistemaNumerico {
    public static void main(String[] args) {

       /* int numeroDecimal = 500;
        System.out.println("numeroDecimal = " + numeroDecimal);

        System.out.println("numero binario de  = " + numeroDecimal + "="+Integer.toBinaryString(numeroDecimal));

        int numeroBinario = 1111110100;
        System.out.println("numeroBinario = " + numeroBinario);

        System.out.println("numero Octal de  = " + numeroBinario+ "="+Integer.toOctalString(numeroDecimal));

        int numeroOctal = 0764;
        System.out.println("numeroOctal = " + numeroOctal);

        System.out.println("numero Hexadecimal de  = " + numeroOctal+ "=" + Integer.toHexString(numeroDecimal));
        int numeroHex = 0x1f4;
        System.out.println("numeroHex = " + numeroHex);
*/

        String numeroStr= JOptionPane.showInputDialog(null,"Ingrese un numero Entero:");//Ventana de dialogo o mensaje
        int numeroDecimal = 0;
        try{
            numeroDecimal =Integer.parseInt(numeroStr);
        }catch (NumberFormatException e){
            JOptionPane.showMessageDialog(null,"Eror debe ingresar un numero entero");
            main(args);
            return;
        }

        System.out.println("numeroDecimal = " + numeroDecimal);

        String resultadoBinario =("numero binario de  = " + numeroDecimal + "="+Integer.toBinaryString(numeroDecimal));
        System.out.println(resultadoBinario);

        int numeroBinario = 1111110100;
        System.out.println("numeroBinario = " + numeroBinario);

        String resultadoOctal = ("numero Octal de  = " + numeroBinario+ "="+Integer.toOctalString(numeroDecimal));
        System.out.println(resultadoOctal );
        int numeroOctal = 036;
        System.out.println("numeroOctal = " + numeroOctal);

        String resultadoHex =("numero Hexadecimal de  = " + numeroOctal+ "=" + Integer.toHexString(numeroDecimal));
        System.out.println(resultadoHex  );
        int numeroHex = 0x1f4;
        System.out.println("numeroHex = " + numeroHex);

        String mensaje = resultadoBinario;
        mensaje += "\n" + resultadoOctal;
        mensaje += "\n" + resultadoHex;

        JOptionPane.showInputDialog(null,mensaje);

    }
}
