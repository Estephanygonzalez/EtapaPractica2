public class ConversionDeTipos {
    public static void main(String[] args) {
    String numeroStr ="50";

    int numeroInt = Integer.parseInt(numeroStr); //Str at Int
    System.out.println("numeroInt = " + numeroInt);

    String realStr = "98457.47";//String at Double
    double realDouble =Double.parseDouble(realStr);
    System.out.println("realDouble = " + realDouble);

    String logicoStr = "true";
    boolean logicoBoolean = Boolean.parseBoolean(logicoStr);
    System.out.println("logicoBoolean = " + logicoBoolean);

    var numero ="50";

    var numeroInt1 = Integer.parseInt(numeroStr);
    System.out.println("numeroInt1 = " + numeroInt1);

    var realStr1 ="984884.43e-3";
    var realDouble1 = Double.parseDouble(realStr1);
    System.out.println("realDouble1 = " + realDouble1);

    var logicoStr1 ="TRUE";
    var logicoBoolean1 = Boolean.parseBoolean(logicoStr);
        System.out.println("logicoBoolean1 = " + logicoBoolean1);






    }
}
