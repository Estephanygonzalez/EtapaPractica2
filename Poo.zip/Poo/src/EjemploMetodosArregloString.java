import java.util.Scanner;

public class EjemploMetodosArregloString {
    public static void main(String[] args) {

        String trabalenguas ="trabalenguas";
        System.out.println("trabalenguas.toCharArray() = " + trabalenguas.toCharArray());

        char[] arreglo = trabalenguas.toCharArray();
        int large = arreglo.length;
        System.out.println("large = " + large);
        for(int i = 0; i <large; i++) {
            System.out.println("arreglo = " + arreglo);
        }

        System.out.println();
        System.out.println("trabalenguas.split(\"a\") = " + trabalenguas.split("a"));
        //Split divide el objeto

        String[] arreglo2 = trabalenguas.split("a");
        int l =arreglo2.length;
        for (int j=0; j<l; j ++){
            System.out.println("arreglo2[j] = " + arreglo2[j]);
        }



    }
}
