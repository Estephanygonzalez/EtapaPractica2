public class PrecedenciaOperadores {
    public static void main(String[] args) {
        int i = 14;
        int j = 8;
        int k = 28;
        
        double promedio = (i + j + k) / 3;//Importante () Para dar Prioridad
        System.out.println("promedio = " + promedio);

        promedio = i + j + k / 3d * 10;
        System.out.println("promedio = " + promedio);


        //Modo depuracion o procedencia ,Selecciona la linea de codigo y en vez de Run se le da en debug//

        

    }
}
