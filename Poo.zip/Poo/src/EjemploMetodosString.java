public class EjemploMetodosString {
    public static void main(String[] args) {
        String nombre = "Felipe";

        System.out.println("nombre.length() = " + nombre.length());
        System.out.println("nombre.toUpperCase() = " + nombre.toUpperCase());
        System.out.println("nombre.toLowerCase() = " + nombre.toLowerCase());
        System.out.println("nombre.equals(\"Felipe\") = " + nombre.equals("Felipe"));
        System.out.println("nombre.equals(\"Felipe\") = " + nombre.equals("Felipe"));
        System.out.println("nombre.equalsIgnoreCase(\"Felipe\") = " + nombre.equalsIgnoreCase("Felipe"));
        System.out.println("nombre.compareTo(\"Felipe\") = " + nombre.compareTo("Felipe"));
        System.out.println("nombre.compareTo(\"David\") = " + nombre.compareTo("Felipe"));
        System.out.println("nombre.chartAt(0)(\"Felipe\") = " + nombre.charAt(0));
        System.out.println("nombre.charAt(1) = " + nombre.charAt(1));
        System.out.println("nombre.charAt(nombre.length()) = " + nombre.charAt(nombre.length()-1));

        System.out.println("nombre.substring(1) = " + nombre.substring(1));
        System.out.println("nombre.substring = " + nombre.substring(1,4));

        String trabalenguas ="trabalenguas";
        System.out.println("trabalenguas =" + trabalenguas.replace("a","."));
        //Replace es para cambiar un String,Retorna una nueva Instancia
        System.out.println("trabalenguas =" + trabalenguas);
        System.out.println("trabalenguas.indexOf = " + trabalenguas.indexOf('a'));
        //IndexOf Posicion en la que encuentra el caracter ->Entrega la 1° Posicion
        System.out.println("trabalenguas.lastIndexof= " + trabalenguas.lastIndexOf('a'));
        //LastIndexof Entrega la ultima posicion del caracter o string
        System.out.println("trabalenguas.indexOf('t') = " + trabalenguas.indexOf('t'));
        //si es menor o negativo No encontro el String O caracter
        System.out.println("trabalenguas.contains(\"t\") = " + trabalenguas.contains("t"));
        //Contains ->Lo contiene si(True) o no (False)
        System.out.println("trabalenguas.startsWith(\"lenguas\") = " + trabalenguas.startsWith("lenguas"));
        //Indica si comienza o no el string con esa composiion,True o False
        System.out.println("trabalenguas.endsWith(\"lenguas\") = " + trabalenguas.endsWith("lenguas"));
        //Indica si termina con ....
        System.out.println(" trabalenguas ");
        System.out.println(" trabalenguas " .trim());
        //Quita los espacios


    }
}
