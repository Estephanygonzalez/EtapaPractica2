public class CalcularTrianguloOperadores {
    public static void main(String[] args) {
        //Calcular el area de un Triangulo
        var base = 4;
        var altura = 5;
        var area = 0;

        area = base * altura /2;
        System.out.println("area ="+ area);

    }
}
