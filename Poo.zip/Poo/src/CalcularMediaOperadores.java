public class CalcularMediaOperadores {
    public static void main(String[] args) {
        /*
        Un alumno tiene las siguientes notas en los examenes : 5.25 , 7.85 ,3.4 Calcula cual es
        la media de este trimestre.A parte todos los alumnos reciben 1 punto mas de la media por un
        trabajo que hicieron,Muestra por pantalla su nota final.

         */

        float n1 = 5.25f;
        float n2 = 7.8f;
        float n3 =3.4f;
        float num =3;
        float media = 0;

        media = (n1+n2+n3)/num;
        System.out.println("media = " + media);

        media ++;
        System.out.println(" la media es = " + media);

        //Igualdad ,diferencia y comparacion

        var a1 = 3;
        var b1 = 2;
        var c1 = (a1 == b1);
        System.out.println("c1 = " + c1);

        var d1 = a1 != b1;
        System.out.println("d1 = " + d1);

        var cadena1 = "Hola";
        var cadena2 = "Adios";

        var e1 = cadena1 == cadena2;//Comparacion de Objetos
        System.out.println("e1 = " + e1);

        var f1 = cadena1.equals(cadena2);//Comparacion de cadenas (Equals)
        System.out.println("f1 = " + f1);

        //Operadores Relacionales

        if (a1%2==0){
            System.out.println(" Es un numero par ");
        }else{
            System.out.println("Es un numero impar");
        }

        //Exercise 2//

        var edad3 = 30;
        var adulto = 18;
        if (edad3 >=adulto) {
            System.out.println("Es un adulto" );
        }else{
            System.out.println("Es menor de edad");
        }
        
        //Operadores Condicionales//
        
        var valorMinimo = 0;
        var valorMaximo = 10;
        var valor1 = 10;
        
        var resultado = valor1 >=0 && valor1 <= 10;
        if(resultado == true){
            System.out.println("Deentro del rango");
        }else{
            System.out.println(" fuera del rango");
        }

        //Example 3//
        
        var vacaciones = false;
        var diaDescanso = false;
        
        if (vacaciones || diaDescanso){
            System.out.println(" el padre puede asistir al juego de su hijo");
            
        }else{
            System.out.println("El padre esta ocupado");
        }
        //Operador Ternario //
        
        var result = (3>2)?"verdadero":"falso";
        System.out.println("result = " + result);
    }
}
