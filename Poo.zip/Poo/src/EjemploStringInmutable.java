public class EjemploStringInmutable {
    public static void main(String[] args) {
        String curso = "Programacion Java";//instancia en la literal STRING
        String teacher = "Juanito lopez";

        String detalle = curso + " con el instructor" + teacher;//concatenar
        System.out.println("detalle = " + detalle);

        int numeroA = 10;
        int numeroB = 5;

        System.out.println(detalle+numeroA+ numeroB);//concatena como un String

        System.out.println(numeroA + (numeroB+detalle));

        String detalle2 = curso.concat("".concat(teacher));
        System.out.println("detalle2 = " + detalle2);










    }
}
