public class ArraysEjercicios1 {
    public static void main(String[] args) {
     //Array es un conjunto de elementos del mismo tipo//
        // Poseen una posicion Unica 0,1,2,3,4//
        //Tipos de datos,Corchetes

        //Indiando su dimension o Lenght
        int[] numeros = new int[3];
        numeros[0] = 100;
        numeros[1] = 230;
        numeros[2] = 549;

        //Inicializando Directamente
        int[] numero1 ={100,230,450};



    }
}
