public class EjercicioOperadoresAritmeticos {
    public static void main(String[] args) {
        var a = 8;
        var b = 3;
        var c =-5;
        
        var suma = a+b+c;
        System.out.println("suma = " + suma);

        var divisionA = a/b;
        System.out.println("divisionA = " + divisionA);

        var divisionC = a/c;
        System.out.println("divisionA = " + divisionC);

        var  Operador1 = a*b/c;
        System.out.println("Operador1 = " + Operador1);

        var Operador2 = (a*c)%b;
        System.out.println("Operador2 = " + Operador2);

        var Operador3 = (3 * a - 2 * b)%(2 * a - c);
        System.out.println("Operador3 = " + Operador3);

        var Operador4 = (a - 3 * b)% (c + 2 * a)/(a-c);
        System.out.println("Operador4 = " + Operador4);

        var Operador5 = a % b;
        System.out.println("Operador5 = " + Operador5);

        //Double
        Double x = 88d , y = 3.5 , z =-5.2;
        
        var Operador6 = x+y+z;
        System.out.println("Operador6 = " + Operador6);

        var Operador7 = x/y ;
        System.out.println("Operador7 = " + Operador7);

        var Operador8 = x/(y+z);
        System.out.println("Operador8 = " + Operador8);

        var Operador9 = 2 *x/ 3*y;
        System.out.println("Operador9 = " + Operador9);

        //entrada datos//

        int altura = 60;
        int base = altura + 6;
        int perimetro = 0;

        perimetro = 2*base + 2*altura;

        System.out.println(perimetro);

        






    }
}
