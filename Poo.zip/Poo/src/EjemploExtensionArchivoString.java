public class EjemploExtensionArchivoString {
    public static void main(String[] args) {
    
        String archivo = "alguna_imagen.jpeg";
        int i = archivo.indexOf(".");
        System.out.println("archivo.length() = " + archivo.length());
        System.out.println("archivo.substring((archivo.length()-4)) = " + archivo.substring(archivo.length()-4));


    }
}
