import java.util.Scanner;

public class EjercicioManejodeNombres {
    public static void main(String[] args) {
         /*
        La tarea consiste en crear una clase llamada Programa ManejoDeNombres de la siguiente manera:
        Se requiere desarrollar un programa que reciba los nombres de 3 integrantes de tu
        familia o amigos como argumentos de línea de comandos.
        Se pide por cada nombre de la persona una nueva variable del tipo String al tomar el segundo
        carácter pero convertido en mayúscula y se le concatena un punto y los dos últimos caracteres
        de la persona. Por ejemplo para Andres debe quedar como N.es
        Debe imprimir como resultado los tres nuevos nombres separado con guion bajo
        (como una única variable).Ejemplo, un resultado final esperado para
        los nombres Andres, Maria y Pepe podría ser:N.es_A.ia_E.pe
         */


        Scanner Scanner = new Scanner(System.in) ;
        System.out.println("Hola,Ingresa el Nombre de un familiar");
        String nombre1 = Scanner.nextLine();
        String nombre1a =nombre1.toUpperCase().charAt(1) + " . " + (nombre1.length()-2) ;

        Scanner nameScanner = new Scanner(System.in) ;
        System.out.println("Hola,Ingresa el nombre de un familiar");
        String nombre2 = nameScanner.nextLine();
        String nombre2a =nombre2.toUpperCase().charAt(1) + " . " + (nombre2.length()-2) ;

        Scanner nombreScanner = new Scanner(System.in) ;
        System.out.println("Hola,Ingresa el nombre de un familiar");
        String nombre3 = nombreScanner.nextLine();
        String nombre3a =nombre3.toUpperCase().charAt(1) + " . " + (nombre3.length()-2) ;

        String Total = nombre1a + nombre2a + nombre3a ;
        System.out.println("Total = " + Total);





    }
}
