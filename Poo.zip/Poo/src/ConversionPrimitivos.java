public class ConversionPrimitivos {
    public static void main(String[] args) {
        int i = 10000;//Integer menor que long
        short s =(short) i;//Integer menor a SHORT
        System.out.println("s = " + s);
        long l = i ;
        System.out.println("l"+ l);
        System.out.println(Short.MAX_VALUE);
        System.out.println(Short.MIN_VALUE);
        char b = (char) i;
        System.out.println("b = " + b);
        float f =(float )i;
        System.out.println("f = " + f);



    }
}
