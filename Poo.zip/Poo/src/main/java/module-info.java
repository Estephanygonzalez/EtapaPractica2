module com.example.poo {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.poo to javafx.fxml;
    exports com.example.poo;
}