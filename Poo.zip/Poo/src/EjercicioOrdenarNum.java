import java.util.Scanner;

public class EjercicioOrdenarNum {
    public static void main(String[] args) {
         /*El desafío es un programa que pida dos números y los muestre ordenados de mayor a menor.

                Podría ser operador utilizando ternario.*/

        Scanner s = new Scanner(System.in);

        System.out.println("Ingrese el numero 1: ");
        int num1 = s.nextInt();

        System.out.println("Ingrese el numero 2: ");
        int num2 = s.nextInt();

        String resultado = (num1 > num2) ? num1 + " y " + num2 : num2 + " y " + num1;

        System.out.println("El orden es: " + resultado);
        
        //Menor a Mayor//
        
        Scanner c = new Scanner(System.in);
        System.out.println("Ingresa el Primer Numero:");
        int numA = c.nextInt();

        System.out.println("Ingresa el Primer Numero:");
        int numB= c.nextInt();
        
        String total = (numB<numA)?numB + "y " + numA :numA + "Y" + numB;
        System.out.println("total = " + total);






    }
    }

