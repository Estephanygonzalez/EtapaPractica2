package Condicionales;

import java.util.Scanner;

public class SentenciaIf {
    public static void main(String[] args) {
        //si se cumpe-If//
        //Sino se cumple//Else

        float promedio = 5.8f;

        if(promedio >=6.5){
            System.out.println("Felicitaciones Excelente promedio");

        }else if (promedio >=6.0) {
            System.out.println("Muy buen promedio");
        } else if (promedio >=5.5) {
            System.out.println("Necesitas Esforzarte un poco mas");
        }

        //Calcular 1 Mes para saber si es bisiesto o no

        Scanner s =new Scanner(System.in);
        System.out.println("Ingrese el numero del mes de 1 a 12");
        int mes = s.nextInt();

        int numeroDias=0;

        Scanner y = new Scanner(System.in);
        System.out.println("Ingrese el año ");
        int year = y.nextInt();

        if(mes == 1 || mes ==3 || mes==5 || mes==7 || mes==8|| mes==10|| mes ==12){
            numeroDias = 31;
        } else if (mes==4 || mes==6|| mes == 9 || mes==11) {
            numeroDias = 30;
        }else if (mes == 2){
            if(year % 400 == 0 || ( (year % 4 == 0) &&! (year % 100 == 0))){
                numeroDias = 29;
            }else {
                numeroDias = 28;
            }
        }

        System.out.println("numeroDias = " + numeroDias);


    }
}