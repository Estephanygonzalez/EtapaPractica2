package Condicionales;

import javax.swing.*;

public class SentenciaFor {
    public static void main(String[] args) {
        //for rango de veces de interaccion ,Conocen los limites//
        int i =0;
        for (;i <= 5;i++){//conveniente use keys
            System.out.println("i =" + i);
        }
        System.out.println("i = " + i);

        String [] nombres = {"andres","Maria","Pipe","Lula","David"};//for arreglos
        int count = nombres.length;
        for ( int n = 0 ;n < count ; n ++ ){
            if(nombres[n].equalsIgnoreCase("andres") ||
                    nombres[n].equalsIgnoreCase("pipe")){
                continue;
            }

            System.out.println("nombres = " + nombres[n]);

        }
        String buscar = JOptionPane.showInputDialog("Ingrese un nombre , ejemplo : Pipe o Andres");
        System.out.println("buscar = " + buscar);

        boolean encontrado =  false;

        for (int n = 0; n <count; n++){
            if (nombres[n].equalsIgnoreCase(buscar)){
                encontrado = true;
                break;
            }
        }
        if (encontrado) {
            JOptionPane.showMessageDialog(null,buscar + "Fue encontrado !");

        }else {
            JOptionPane.showMessageDialog(null,buscar +"No fue encontrado");
        }


    }
}
