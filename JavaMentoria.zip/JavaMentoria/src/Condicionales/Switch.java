package Condicionales;

import java.util.Scanner;

public class Switch {
    public static void main(String[] args) {

        /*El condicional switch case es una estructura que evalúa más de un caso y se
        caracteriza por: Selección de una opción entre varias.
         */
        int num = 3;

        switch (num) {
            case 0:
                System.out.println("El num es cero");
                break;
            case 1:
                System.out.println("El num es uno");
                break;
            case 2:
                System.out.println("El num es dos");
                break;
            case 3:
                System.out.println("El numero es tres");


        }
        //Como obtener el mes
        Scanner m = new Scanner(System.in);
        System.out.println("Escribe un numero del 1 al 12 de un mes ");
        int mes = m.nextInt();
        String nombreMes = null;
        switch (mes) {
            case 1:
                nombreMes = "Enero";
                break;
            case 2:
                nombreMes = "Febrero";
                break;
            case 3:
                nombreMes = "marzo";
                break;
            case 4:
                nombreMes = "Abril";
                break;
            case 5:
                nombreMes = "Mayo";
                break;
            case 6:
                nombreMes = "Junio";
                break;
            case 7:
                nombreMes = "Julio";
                break;
            case 8:
                nombreMes = "Agosto";
                break;
            case 9:
                nombreMes = "Septiembre";
                break;
            case 10:
                nombreMes = "Octubre";
                break;
            case 11:
                nombreMes = "Noviembre";
                break;
            case 12:
                nombreMes = "Diciembre";
                break;
            default:
                nombreMes = "Indefinido";
                break;
        }
        System.out.println("El mes es = " + nombreMes);


        //Obtener numero dias del mes//

        Scanner s = new Scanner(System.in);
        System.out.println("Ingrese el numero del mes de 1 a 12");
        int month = s.nextInt();

        int numeroDias = 0;

        Scanner y = new Scanner(System.in);
        System.out.println("Ingrese el año ");
        int year = y.nextInt();

        switch (month) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                numeroDias = 31;
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                numeroDias = 30;
                break;
            case 2:
                if (year % 400 == 0 || ((year % 4 == 0) && !(year % 100 == 0))) {
                    numeroDias = 29;
                } else {
                    numeroDias = 28;
                }
                break;
            default:
                numeroDias = 0;

        }

    }
}