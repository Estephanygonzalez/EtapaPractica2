package JavaBasics.TiposDatos;

public class PrimitivoFloat {
    public static void main(String[] args) {

        float realfloat = 1;
        System.out.println("realfloat = " + realfloat);

        float realfloat1 = 19239f;//Al agregar la f lo toma como Float
        System.out.println("realfloat1 = " + realfloat1);

        float realfloat2 = 192.39e4f;//1923900.0
        System.out.println("realfloat2 = " + realfloat2);

        float realfloat3 = 0.000000000015f;//1.5E-11f;
        System.out.println("realfloat3 = " + realfloat3);


        float realfloat4 = 0.000000000015f;//1.5E-11f;
        System.out.println("numero Float = " + realfloat4);
        System.out.println("tipo Float corresponde en byte a " + Float.BYTES);
        System.out.println("tipo Float corresponde en byte a " + Float.SIZE);
        System.out.println("Valor Maximo de un Float " + Float.MAX_VALUE);
        System.out.println("Valor Minimo de un Float " + Float.MIN_VALUE);


        double realDouble = 3.4567893E9;
        System.out.println("numero Double = " + realDouble);
        System.out.println("tipo Double corresponde en byte a " + Double.BYTES);
        System.out.println("tipo Double corresponde en byte a " + Double.SIZE);
        System.out.println("Valor Maximo de un Double " + Double.MAX_VALUE);
        System.out.println("Valor Minimo de un Double " + Double.MIN_VALUE);
    }
}
