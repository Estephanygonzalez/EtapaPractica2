package JavaBasics.TiposDatos;

public class PrimitivosChar {
    public static void main(String[] args) {
        char decimal = 64;
        System.out.println("decimal = " + decimal);

        char simbolo = '@';
        System.out.println("simbolo ="+ simbolo);

        //Tipo Boolean

        boolean datologico = false;
        System.out.println("datologico = " + datologico);

        boolean datologico1 = Boolean.FALSE;//Instancia Boolean
        System.out.println("datologico = " + datologico1);

        double d= 98765.43e-3;//98.76543;
        System.out.println("d = " + d);
        float  f=1.23456e2f;//123.45
        System.out.println("f = " + f);

        datologico = d>f;
        System.out.println("datalogico = " + datologico);//False

        boolean esIgual = 3-2 == 1;
        System.out.println("esIgual = " + esIgual);//True







    }
}
