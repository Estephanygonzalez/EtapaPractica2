package JavaBasics.TiposDatos;

public class Primitivos {
    public static void main (String[] args){

        byte numeroByte = 127;//Valor Maximo
        System.out.println("numeroByte = " + numeroByte);
        System.out.println("tipo byte corresponde en byte a " + Byte.BYTES);
        System.out.println("tipo byte corresponde en byte a " + Byte.SIZE);
        System.out.println("Valor Maximo de un Byte  " + Byte.MAX_VALUE);
        System.out.println("Valor Minimo de un Byte " + Byte.MIN_VALUE);

        short numeroShort = 30000;
        System.out.println("numero Short = " + numeroShort);
        System.out.println("tipo Short corresponde en byte a " + Short.BYTES);
        System.out.println("tipo Short corresponde en byte a " + Short.SIZE);
        System.out.println("Valor Maximo de un Short " + Short.MAX_VALUE);
        System.out.println("Valor Minimo de un Short " +Short.MIN_VALUE);

        int numeroInt = 32764;
        System.out.println("numero Int = " + numeroInt);
        System.out.println("tipo Int corresponde en byte a " + Integer.BYTES);
        System.out.println("tipo Int corresponde en byte a " + Integer.SIZE);
        System.out.println("Valor Maximo de un Int " + Integer.MAX_VALUE);
        System.out.println("Valor Minimo de un Int " +Integer.MIN_VALUE);

        long numeroLong = 328485900;
        System.out.println("numero Long= " + numeroLong);
        System.out.println("tipo Long corresponde en byte a " + Long.BYTES);
        System.out.println("tipo Long corresponde en byte a " + Long.SIZE);
        System.out.println("Valor Maximo de un Long " + Long.MAX_VALUE);
        System.out.println("Valor Minimo de un Long " +Long.MIN_VALUE);

    }
}
