package Ejercicios;

/*Reciba el nombre de la factura o descripción, utilizar método nextLine()
 para obtener el nombre de la factura con espacios.
 Reciba 2 precios de productos de tipo double, utilizar método nextDouble()
 para obtener precios con decimales (,).
 Calcule el total, sume ambos precios y agregue un valor de impuesto del 19%
 Se pide mostrar en un solo String el nombre de la factura, el monto total bruto
 (antes de impuesto), el impuesto y el monto total neto incluyendo impuesto.
 */

import java.util.Scanner;

public class Exercise01DetalleFactura {
    public static void main(String[] args) {
        String factura;
        Scanner Scr = new Scanner(System.in);
        System.out.println("Hola,Escribe el nombre de tu factura o una descripcion breve");
        factura =Scr.nextLine();

        System.out.println("Digita el Precio del producto N° 1");
        double precio1 = Scr.nextDouble();

        System.out.println("Digita el Precio  del producto N° 2");
        double precio2 = Scr.nextDouble();

        double totalBruto = precio1 + precio2;
        double impuesto = totalBruto * 0.19;
        double totalNeto = totalBruto + impuesto;

        System.out.println(" Nombre de la factura : " + factura + "\n"+"Precio del producto N°1"+ precio1+"\n"+
                "Precio del producto N°2"+precio2+"\n"+"total bruto"+totalBruto+"\n"+"Impuesto"+ impuesto+"\n"+
                "totalNeto"+totalNeto);




    }
}
