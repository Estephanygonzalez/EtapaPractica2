package generationMet;

import java.util.Scanner;

public class ClassScanner1 {
    public static void main(String[] args) {
        /*
        nextBoolean()
        nextByte()
        nextDouble()
        nextFloat()
        nextInt()
        nextLine()
        nextLong()
        nextShort()
         */
        System.out.println("Ingrese la Edad");
        Scanner entrada = new Scanner(System.in);//Entrada de datos

        int edad = entrada.nextInt();
        System.out.println("La edad Ingresada Es = " + edad);





    }
}
