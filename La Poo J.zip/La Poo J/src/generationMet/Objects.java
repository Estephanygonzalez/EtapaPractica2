package generationMet;

public class Objects {
    //Crear un objeto a partir de un objeto -Instancia
    public static void main(String[] args) {
        GetAndSet g1 = new GetAndSet("limon","verde");
        g1.mostrarInfo1();

        GetAndSet g2 = new GetAndSet("Azul","Arandano");
        g2.mostrarInfo1();

    }


}
