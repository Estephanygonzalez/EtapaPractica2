package generationMet;

import generationMet.Automovil;

public class EjemploAutomovil {
    public static void main(String[] args) {

        Automovil subura = new Automovil();
        subura.asignarFabricante("Subura");
        subura.asignarModelo( "Nissan");
        subura.asignarColor("Rojo");
        subura.asignarCilindrada(2.0);

        Automovil mazda = new Automovil();
        mazda.fabricante = "Mazda";
        mazda.modelo = "Bt-50";
        mazda.color = "gris";
        mazda.cilindrada = 3.4;

        System.out.println("mazda = " + mazda.fabricante);
        System.out.println("mazda.modelo = " + mazda.modelo);
        System.out.println("mazda.color = " + mazda.color);
        System.out.println("mazda.cilindrada = " + mazda.cilindrada);


        System.out.println(subura.verDetalle());
        System.out.println(mazda.verDetalle());
        System.out.println(subura.acelerar(4500));
        System.out.println(subura.frenar());

        System.out.println(mazda.acelerarFrenar(4000));

        System.out.println(" Kilometros por litro " +subura.calcularConsumo(300,0.75F));




   
   
   
    }
}
