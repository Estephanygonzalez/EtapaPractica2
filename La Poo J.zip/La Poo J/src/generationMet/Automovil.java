package generationMet;

public class Automovil{

        String fabricante;
        String modelo;
        String color;
        double cilindrada;
        int capacidadEstanque = 40;

        public String getFabricante() {
                return fabricante;
        }
/*public  String detalle (){
                StringBuilder sb = new StringBuilder();
                sb.append("auto.fabricante = " + this.fabricante);
                sb.append("auto.modelo = " + this.modelo);//this call a method
                sb.append("auto.color = " + this.color);
                sb.append("auto.cilindrada = " + this.cilindrada);
                return sb.toString();

         */

        public String LeerFabricante(){
                return this.fabricante;
        }

        public String getModelo() {
                return modelo;
        }

        public void asignarFabricante(String fabricante){
                this.fabricante = fabricante;
        }
        public String LeerModelo (){
                return modelo;
        }
        public void asignarModelo(String modelo){
                this.modelo = modelo;
        }
        public String LeerColor(){
                return color;
        }
        public void asignarColor(String color){
                this.color = color;
        }
        public Double LeerCilindrada(){
                return cilindrada;
        }
        public void asignarCilindrada(Double cilindrada){
                this.cilindrada = cilindrada;
        }
        public int LeerCapacidadEstanque(){
                return capacidadEstanque;
        }
        public void asignarCapacidadEstanque(int capacidadEstanque){
                this.capacidadEstanque = capacidadEstanque;
        }
        public String verDetalle() {
                return "auto.fabricante =" + this.fabricante +
                        "\nauto.modelo   =" + this.modelo +
                        "\nauto.color    =" + this.color +
                        "\nauto.cilindrada =" + this.cilindrada;
        }

        public String acelerar (int rpm){//variable utilizada dentro del metodo
                return "el auto"+fabricante + "acelerado a " + rpm + "rpm";
        }
        public String frenar (){
                return this.fabricante + " "+ this.modelo + "frenando!";
        }

        public String acelerarFrenar(int rpm){
                String acelerar = this.acelerar(rpm);
                String frenar = this.frenar();
                return acelerar + "\n" + frenar;
        }

        public float calcularConsumo(int km, float porcentajeBencina){
                return km/(capacidadEstanque*porcentajeBencina);

        }


    }


