package generationMet;

public class GetAndSet {
    //Atributos
    String sabor;
    String color;

    //Metodo Constructor

    public GetAndSet(String sabor, String color){
        this.sabor = sabor;
        this.color = color;

    }

    //Method Getters and setters


    public String getSabor() {
        return sabor;
    }

    public void setSabor(String sabor) {
        this.sabor = sabor;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    //Method toString->Muestra Info atributos



    public void mostrarInfo1() {
        System.out.println("Gelatna2{" +
                "sabor='" + sabor + '\'' +
                ", color='" + color + '\'' +
                '}');


    }
}
