package Encapsulamiento;

public class Persona {
    public int getEdad() {
        if(this.edad ==0){
            System.out.println(" Debe ingresar una edad valida antes de visualizarla " );
        }
        return edad;
    }

    private int edad;//Acceso private

    public void setEdad(int edad) {
        if (edad >= 0) {
            this.edad = edad;//this referencia al object actually
        }


    }
}

