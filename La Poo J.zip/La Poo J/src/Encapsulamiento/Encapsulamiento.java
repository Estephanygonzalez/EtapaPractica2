package Encapsulamiento;
//Permite definir niveles de visibilidad para los elementos de la clase
//Como: Default,Public,privado

public class Encapsulamiento {
    public static void main(String[] args) {

        Persona p = new Persona();
        p.setEdad(18);

        System.out.println("La edad ingresada es :" + p.getEdad());




    }


}
